GenStats 1.0.0

About:
This program generates stats based on the log files from the amxx plugins called
Server preformance monitor. Check screenshot on what it looks like

Usage:
Simple drag & drop the file onto this .exe 

This program requires:
.Net framework ( see links at bottom )
Plugin version above 1.0.1

Links:
Plugin thread: http://www.amxmodx.org/forums/viewtopic.php?t=2290
Microsoft .NET Framework Version 1.1: http://www.microsoft.com/downloads/details.aspx?FamilyID=262d25e3-f589-4842-8157-034d1e7cf3a3&DisplayLang=en

Bugs:
I dont care about them. This program is very much a beta