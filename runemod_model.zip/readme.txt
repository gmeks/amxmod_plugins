This model is used to make the runemod runes look better, instead of using the HL weapon box, 
we use this model.
To install it simply place it in your mod/models/runemod/ folder

Example: cstrike/models/runemod/

Runemod 2.0 automaticly checks to see if this model exists, if it does it will be used. Remember to use this
model you need runemod 2.0 , not runemod 2.0 Release candidate X